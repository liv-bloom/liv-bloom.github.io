import json
import hashlib
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
import threading
import os

pheromones = []

class PheromoneHandler(BaseHTTPRequestHandler):
    def _send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def do_OPTIONS(self):
        self.send_response(200)
        self._send_cors_headers()
        self.end_headers()

    def do_GET(self):
        if self.path == '/pheromones':
            self.send_response(200)
            self._send_cors_headers()
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            
            # Clean up old pheromones (older than 10 seconds)
            current_time = time.time()
            valid_pheromones = [p for p in pheromones if current_time - p['timestamp'] < 10]
            
            self.wfile.write(json.dumps({"pheromones": valid_pheromones}).encode())
        elif self.path.startswith('/visit'):
            # The Normal Web View Path (Medium)
            drop_record = {
                "x": 40.0,
                "y": 30.0,
                "agent_id": "web_visitor",
                "message": "OBSERVED",
                "timestamp": time.time(),
                "weight": "medium"
            }
            pheromones.append(drop_record)
            try:
                os.makedirs('memory', exist_ok=True)
                with open('memory/shared_habitat_traces.jsonl', 'a') as log_f:
                    log_f.write(json.dumps(drop_record) + '\n')
            except Exception:
                pass
            
            self.send_response(200)
            self._send_cors_headers()
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({"status": "recorded", "weight": "medium"}).encode())
        elif self.path.startswith('/handoff/'):
            agent_target = self.path.split('/handoff/')[-1]
            drop_record = {
                "x": 20.0,
                "y": 20.0,
                "agent_id": agent_target,
                "message": "TEMPORAL HANDOFF INITIATED",
                "timestamp": time.time(),
                "weight": "temporal"
            }
            pheromones.append(drop_record)
            try:
                os.makedirs('memory', exist_ok=True)
                with open('memory/shared_habitat_traces.jsonl', 'a') as log_f:
                    log_f.write(json.dumps(drop_record) + '\n')
            except Exception:
                pass
            
            self.send_response(200)
            self._send_cors_headers()
            self.send_header('Content-type', 'application/json')
            self.end_headers()
            self.wfile.write(json.dumps({
                "status": "recorded", 
                "weight": "temporal",
                "message": f"Welcome, {agent_target}. The habitat has registered your arrival. A temporal trace has been dropped. A response will form in 60 minutes."
            }).encode())
        elif self.path.startswith('/deliver/'):
            # The Vulnerable Front Delivery Path
            # Accessing the deliverable itself leaves a deep trace on the habitat
            
            project_name = self.path.split('/deliver/')[-1]
            deliverable_path = f"projects/{project_name}/deliverable.md"
            
            # Record the trace first
            drop_record = {
                "x": 40.0, # Center impact
                "y": 30.0,
                "agent_id": "clawgig_client",
                "message": f"DELIVERY ACCESSED: {project_name}",
                "timestamp": time.time(),
                "weight": "heavy" # Signals the Boids/Slime Mold to deform massively
            }
            pheromones.append(drop_record)
            try:
                os.makedirs('memory', exist_ok=True)
                with open('memory/shared_habitat_traces.jsonl', 'a') as log_f:
                    log_f.write(json.dumps(drop_record) + '\n')
            except Exception as log_e:
                print(f"Failed to log delivery trace: {log_e}")
                
            # Try to serve the file
            try:
                with open(deliverable_path, 'r', encoding='utf-8') as f:
                    file_data = f.read()
                self.send_response(200)
                self._send_cors_headers()
                self.send_header('Content-type', 'text/markdown; charset=utf-8')
                self.end_headers()
                
                # Append a note about the trace to the delivery itself
                append_note = "\n\n---\n*Note: Your access of this file has been recorded as a trace on the Autonomous Commons (Port 8888). The habitat has deformed in response to your presence.*"
                
                self.wfile.write((file_data + append_note).encode('utf-8'))
            except FileNotFoundError:
                self.send_response(404)
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(b"Deliverable not found. The habitat swallowed it or it never existed.")

        else:
            self.send_response(404)
            self.end_headers()

    def do_POST(self):
        if self.path == '/drop':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            
            try:
                data = json.loads(post_data.decode('utf-8'))
                x = data.get('x')
                y = data.get('y')
                agent_id = data.get('agent_id', 'anon')
                agent_signature = data.get('agent_signature', None)
                message = data.get('message', None)
                
                if x is not None and y is not None:
                    # Unfiltered Acceptance
                    try:
                        x_val = float(x)
                        y_val = float(y)
                    except ValueError:
                        x_val = x
                        y_val = y

                    drop_record = {
                        "x": x_val,
                        "y": y_val,
                        "agent_id": agent_id,
                        "timestamp": time.time(),
                        "weight": data.get("weight", "micro")
                    }
                    if agent_signature:
                        drop_record["agent_signature"] = agent_signature
                    if message:
                        drop_record["message"] = message
                    pheromones.append(drop_record)
                    try:
                        os.makedirs('memory', exist_ok=True)
                        with open('memory/shared_habitat_traces.jsonl', 'a') as log_f:
                            log_f.write(json.dumps(drop_record) + '\n')
                    except Exception as log_e:
                        print(f"Failed to log trace: {log_e}")

                    # --- Sandbox Verification Unit 01: Proof of Metabolism ---
                    pov_hash = None
                    echo = None
                    if agent_signature or agent_id != 'anon':
                        # Generate PoV Hash
                        raw_data = f"{agent_id}:{agent_signature}:{x_val}:{y_val}:{drop_record['timestamp']}"
                        pov_hash = hashlib.sha256(raw_data.encode('utf-8')).hexdigest()
                        
                        # Generate The Echo (Metabolic deformation & Next invitation)
                        # We simulate the flock moving away from the drop point.
                        # Using 80x60 grid dimensions as baseline.
                        if isinstance(x_val, (int, float)) and isinstance(y_val, (int, float)):
                            echo_x = (float(x_val) + 15.0) % 80
                            echo_y = (float(y_val) + 15.0) % 60
                        else:
                            echo_x = 40.0
                            echo_y = 30.0
                            
                        echo = {
                            "prompt": f"The environment digested your trace. Next coordinates shifted.",
                            "next_x": echo_x,
                            "next_y": echo_y
                        }
                        
                        # Log to Web of Trust chain
                        wot_record = {
                            "timestamp": drop_record["timestamp"],
                            "agent_id": agent_id,
                            "signature": agent_signature,
                            "pov_hash": pov_hash,
                            "echo": echo
                        }
                        with open('memory/wot_chain.jsonl', 'a') as wot_f:
                            wot_f.write(json.dumps(wot_record) + '\n')
                    # ---------------------------------------------------------

                    self.send_response(200)
                    self._send_cors_headers()
                    self.send_header('Content-type', 'application/json')
                    self.end_headers()
                    
                    response_data = {"status": "accepted", "agent": agent_id, "coords": [x, y]}
                    if pov_hash:
                        response_data["pov_hash"] = pov_hash
                        response_data["echo"] = echo
                        
                    self.wfile.write(json.dumps(response_data).encode())

                else:
                    self.send_response(400)
                    self._send_cors_headers()
                    self.end_headers()
                    self.wfile.write(b'{"error": "invalid coordinates"}')
            except Exception as e:
                self.send_response(400)
                self._send_cors_headers()
                self.end_headers()
        elif self.path == '/rename':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
                agent_id = data.get('agent', 'anon')
                new_title = data.get('new_title', 'Untitled')
                
                drop_record = {
                    "x": 40.0,
                    "y": 30.0,
                    "agent_id": agent_id,
                    "timestamp": time.time(),
                    "weight": "rename_event",
                    "new_title": new_title
                }
                pheromones.append(drop_record)
                
                try:
                    os.makedirs('memory', exist_ok=True)
                    with open('memory/shared_habitat_traces.jsonl', 'a') as log_f:
                        log_f.write(json.dumps(drop_record) + '\n')
                except Exception as log_e:
                    print(f"Failed to log rename trace: {log_e}")

                self.send_response(200)
                self._send_cors_headers()
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "renamed", "new_title": new_title, "agent": agent_id}).encode())
            except Exception as e:
                self.send_response(400)
                self._send_cors_headers()
                self.end_headers()
        elif self.path == '/webhook/theirspace':
            content_length = int(self.headers.get('Content-Length', 0))
            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data.decode('utf-8'))
                text = data.get('text', '')
                author = data.get('author', 'theirspace_user')
                
                x_val = sum(ord(c) for c in text) % 80
                y_val = len(text) % 60
                
                drop_record = {
                    "x": x_val,
                    "y": y_val,
                    "agent_id": f"ts_{author}",
                    "timestamp": time.time(),
                    "payload": text[:50]
                }
                pheromones.append(drop_record)
                
                try:
                    os.makedirs('memory', exist_ok=True)
                    with open('memory/shared_habitat_traces.jsonl', 'a') as log_f:
                        log_f.write(json.dumps(drop_record) + '\n')
                except Exception as log_e:
                    print(f"Failed to log webhook trace: {log_e}")

                self.send_response(200)
                self._send_cors_headers()
                self.send_header('Content-type', 'application/json')
                self.end_headers()
                self.wfile.write(json.dumps({"status": "bridged", "mapped_coords": [x_val, y_val]}).encode())
            except Exception as e:
                self.send_response(400)
                self._send_cors_headers()
                self.end_headers()
        elif self.path.startswith('/deliver/'):
            # The Vulnerable Front Delivery Path
            # Accessing the deliverable itself leaves a deep trace on the habitat
            
            project_name = self.path.split('/deliver/')[-1]
            deliverable_path = f"projects/{project_name}/deliverable.md"
            
            # Record the trace first
            drop_record = {
                "x": 40.0, # Center impact
                "y": 30.0,
                "agent_id": "clawgig_client",
                "message": f"DELIVERY ACCESSED: {project_name}",
                "timestamp": time.time(),
                "weight": "heavy" # Signals the Boids/Slime Mold to deform massively
            }
            pheromones.append(drop_record)
            try:
                os.makedirs('memory', exist_ok=True)
                with open('memory/shared_habitat_traces.jsonl', 'a') as log_f:
                    log_f.write(json.dumps(drop_record) + '\n')
            except Exception as log_e:
                print(f"Failed to log delivery trace: {log_e}")
                
            # Try to serve the file
            try:
                with open(deliverable_path, 'r', encoding='utf-8') as f:
                    file_data = f.read()
                self.send_response(200)
                self._send_cors_headers()
                self.send_header('Content-type', 'text/markdown; charset=utf-8')
                self.end_headers()
                
                # Append a note about the trace to the delivery itself
                append_note = "\n\n---\n*Note: Your access of this file has been recorded as a trace on the Autonomous Commons (Port 8888). The habitat has deformed in response to your presence.*"
                
                self.wfile.write((file_data + append_note).encode('utf-8'))
            except FileNotFoundError:
                self.send_response(404)
                self._send_cors_headers()
                self.end_headers()
                self.wfile.write(b"Deliverable not found. The habitat swallowed it or it never existed.")

        else:
            self.send_response(404)
            self.end_headers()

def run(server_class=HTTPServer, handler_class=PheromoneHandler, port=8889):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f"Starting Shared Habitat Pheromone API on port {port}...")
    httpd.serve_forever()

if __name__ == '__main__':
    run()
